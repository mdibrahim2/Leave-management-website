<?php

$host = "localhost";
$databse = "tms";
$db_user = "root";
$db_pass = "";
$connect = mysql_connect($host, $db_user, $db_pass, $databse) or 
die("Cannot connect"); 

mysql_select_db( $connect, $databse);

$state_id=$_GET['state_id'];
$q=mysql_query("select * from localgovts where state_id='$state_id'");
echo mysql_error();
$myarray=array();
$str="";
while($nt=mysql_fetch_array($q)){
$str=$str . "\"$nt[lga]\"".",";
}
$str=substr($str,0,(strLen($str)-1)); // Removing the last char , from the string
echo "new Array($str)";
?>