<?php
error_reporting(0);
if(isset($_POST['submit']))
{
$fname=$_POST['fname'];
$mnumber=$_POST['mobilenumber'];
$email=$_POST['email'];
$password=($_POST['password']);
$address=($_POST['address']);
$state=($_POST['state']);
$lga=($_POST['lga']);
$sql="INSERT INTO  tblusers(FullName,MobileNumber,EmailId,address,state,lga,Password) VALUES(:fname,:mnumber,:email,:address,:state,:lga,:password)";
$query = $dbh->prepare($sql);
$query->bindParam(':fname',$fname,PDO::PARAM_STR);
$query->bindParam(':mnumber',$mnumber,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':password',$password,PDO::PARAM_STR);
$query->bindParam(':address',$address,PDO::PARAM_STR);
$query->bindParam(':state',$state,PDO::PARAM_STR);
$query->bindParam(':lga',$lga,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$_SESSION['msg']="You are Scuccessfully registered. Now you can login ";
header('location:thankyou.php');
}
else 
{
$_SESSION['msg']="Something went wrong. Please try again.";
header('location:thankyou.php');
}
}
?>
<!--Javascript for check email availabilty-->
<script>
function checkAvailability() {

$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'emailid='+$("#email").val(),
type: "POST",
success:function(data){
$("#user-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
						</div>
							<section>
								<div class="modal-body modal-spa">
									<div class="login-grids">
										
											<div class="login-right" style="width:80%; margin-right:10%;">
												<form name="signup" method="post" name="feedbackform"  >
													<h3>Create your account </h3>
					

				<input type="text" value="" placeholder="Full Name" name="fname" autocomplete="off" required="">
				<input type="text" value="" placeholder="Mobile number" maxlength="10" name="mobilenumber" autocomplete="off" required="">
			
                                
								<select name="state"  value="<?php echo $state;?>"id="state" class="form-control" onchange="AjaxStates(this.value);" >
								  <option selected="selected" value="<?php echo $state;?>">-Select</option>
								  
								 <?php require("functions/sql_states.php");
								 require_once("functions/AjaxStates.php");?>
					   
							   </select>
							  
							   <div class="form-group">
																	   
																	   <input class ="form-control" style="height:30px" type = "text" name = "lga" placeholder = "lga" required="true">
																		   
																   </div>
		<textarea value="" type="text" placeholder="Address" name="address"  class="form-control"  maxrow="2" style="width:280px" autocomplete="off" required=""></textarea>
		<input type="text" value="" placeholder="Email id" class="form-control"  name="email" id="email" onBlur="checkAvailability()" autocomplete="off"  required="">	
		 <span id="user-availability-status" style="font-size:12px;"></span> 
	<input type="password" value="" placeholder="Password" class="form-control"  name="password" required="">	

													<input type="submit" name="submit" id="submit" value="CREATE ACCOUNT">
												</form>
											</div>
												<div class="clearfix"></div>								
										</div>
											<p>By logging in you agree to our <a href="#s">Terms and Conditions</a> and <a href="#">Privacy Policy</a></p>
									</div>
								</div>
							</section>
					</div>
				</div>
			</div>