<?php
$host = "localhost";
$databse = "sug";
$db_user = "root";
$db_pass = "";
$connect = mysql_pconnect($host, $db_user, $db_pass) or 
die("Cannot connect"); 

mysql_select_db($databse, $connect);
$id=$_GET['id'];
$q=mysql_query("select * from department where faculty_id='$id'");
echo mysql_error();
$myarray=array();
$str="";
while($nt=mysql_fetch_array($q)){
$str=$str . "\"$nt[department]\"".",";
}
$str=substr($str,0,(strLen($str)-1)); // Removing the last char , from the string
echo "new Array($str)";
?>