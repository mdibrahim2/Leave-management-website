<?php
$db_category=mysql_query("select * from departments");
while($db_cat_result=mysql_fetch_array($db_category)){
echo "<option value=$db_cat_result[id]>$db_cat_result[department]</option>";
}
?>