<?php
//define a maxim size for the uploaded images in Kb
 define ("MAX_SIZE","350"); 

//This function reads the extension of the file. It is used to determine if the file  is an image by checking the extension.
 function getExtension($str) {
         $i = strrpos($str,".");
         if (!$i) { return ""; }
         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
 }

//This variable is used as a flag. The value is initialized with 0 (meaning no error  found)  
//and it will be changed to 1 if an errro occures.  
//If the error occures the file will not be uploaded.
 $errors=0;
//checks if the form has been submitted
 if(isset($_POST['submit'])) 
 {
 	//reads the name of the file the user submitted for uploading
	$attachment1=$_FILES['attachment1']['name'];
 	$attachment2=$_FILES['attachment2']['name'];


 	//if it is not empty
	if($attachment1)
	if($attachment2)
	
 	{
 	//get the original name of the file from the clients machine
		$filename1 = stripslashes($_FILES['attachment1']['name']);
		$filename2 = stripslashes($_FILES['attachment2']['name']);
		 	//get the extension of the file in a lower case format
		$extension1 = getExtension($filename1);
  		$extension2 = getExtension($filename2);


		$extension1 = strtolower($extension1);
		$extension2 = strtolower($extension2);
	//otherwise we will do more tests
 if (($extension1 != "jpeg") && ($extension1 != "jpg") && ($extension1 != "png") && ($extension2 != "jpeg") && ($extension2 != "jpg") && ($extension2 != "png")) 
 		{
		//print error message
 			echo '<h1>Unknown extension!</h1>';
 			$errors=1;
 		}
 		else
 		{
//get the size of the image in bytes
 //$_FILES['image']['tmp_name'] is the temporary filename of the file
 //in which the uploaded file was stored on the server
 $size1=filesize($_FILES['attachment1']['tmp_name']);
 $size2=filesize($_FILES['attachment2']['tmp_name']);

//compare the size with the maxim size we defined and print error if bigger
if ($size1 > MAX_SIZE*1024 || $size2 > MAX_SIZE*1024)


{
	 $sizelimit='<h1>You have exceeded the size limit!</h1>';
	$errors=1;
}

//we will give an unique name, for example the time in unix time format
$image_name1=1+time().'.'.$extension1;
$image_name2=2+time().'.'.$extension2;

//the new name will be containing the full path where will be stored (images folder)
$newname1="student_files/".$image_name1;
$newname2="student_files/".$image_name2;

//we verify if the image has been uploaded, and print error instead

if(!$errors){

$copied1 = copy($_FILES['attachment1']['tmp_name'], $newname1);
$copied2 = copy($_FILES['attachment2']['tmp_name'], $newname2);

if (!$copied1 || !$copied2) 
{ 


	echo '<h1>Copy unsuccessfull!</h1>';
	$errors=1;
}}}}

//If no errors registered, print the success message
 if(isset($_POST['submit']) && !$errors) 
  	 if($attachment1=="" || $attachment2==""){ $notupload="Please note that upload fields with * are compulsary for upload!"; }
	 
else
 {

$firstname=checkValues($_POST['firstname']);
$middlename=checkValues($_POST['middlename']);
$lastname=checkValues($_POST['lastname']);
$gender=$_POST['gender'];
$dob=$_POST['dob'];
$country=$_POST['country'];
$state=$_POST['state'];
$city=$_POST['city'];
$address=checkValues($_POST['address']);
$phone=$_POST['phone'];
$email=$_POST['email'];
$institute_name=checkValues($_POST['institute_name']);
$qual_exam_name=$_POST['qual_exam_name'];
$exam_roll_no=$_POST['exam_roll_no'];
$final_score=$_POST['final_score'];
$p_firstname=$_POST['p_firstname'];
$p_lastname=$_POST['p_lastname'];
$relation=$_POST['relation'];
$p_dob=$_POST['p_dob'];
$occupation=checkValues($_POST['occupation']);
$income=$_POST['income'];
$p_country=$_POST['p_country'];
$p_state=$_POST['p_state'];
$p_address=checkValues($_POST['p_address']);
$p_mobile=$_POST['p_mobile'];
$programme=$_POST['programme'];
$username=$_POST['username'];
$password=md5($_POST['password']);
$password2=$_POST['password2'];
$s_question=checkValues($_POST['s_question']);
$s_answer=md5(checkValues($_POST['s_answer']));

//Fields Validation


if(!$error){

$insert=mysql_query("insert into application_form(firstname, middlename, lastname, gender, dob, country, state, city, address, phone,email,institute_name,qual_exam_name,exam_roll_no,final_score,p_firstname,p_lastname,relation,p_dob,occupation,income,p_country,p_state,p_address,p_mobile,programme,passport_photo,avatar,attachment1,attachment2,attachment3,attachment4,username,password,s_question,s_answer) values('$firstname','$middlename','$lastname','$gender','$dob','$country','$state','$city','$address','$phone','$email','$institute_name','$qual_exam_name','$exam_roll_no','$final_score','$p_firstname','$p_lastname','$relation','$p_dob','$occupation','$income','$p_country','$p_state','$p_address','$p_mobile','$programme','$newname','$newname','$newname1','$newname2','$newname3','$newname4','$username','$password','$s_question','$s_answer')");

if(!$insert){ 

echo  '<script language="javascript">window.alert("Error; Form was not Submitted"); window.location="error.php";</script>';
}else
 echo  '<script language="javascript">window.alert("Application was submitted Successfully"); window.location="index.php";</script>';
}
 else
 
 { 
  echo  '<script language="javascript">window.alert("Invalid entries");</script>';
}


}
 }

?>