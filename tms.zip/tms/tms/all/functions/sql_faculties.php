<?php
$db_category=mysql_query("select * from faculties ");
while($db_cat_result=mysql_fetch_array($db_category)){
	
echo "<option $md=$db_cat_result[faculty]; name=$db_cat_result[id] value= $db_cat_result[id]> $db_cat_result[faculty]</option>";

}
?>