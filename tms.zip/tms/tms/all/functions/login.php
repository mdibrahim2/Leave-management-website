<?php
if(isset($_POST['submit']))
{
$username= check($_POST['username']);
$username=strtolower($username);
$password= check($_POST['password']);
$password= md5($password);

//Query for Administrators
$sql_login=mysql_query("select * from administrators where username='$username' and password='$password' and del_status != 'D'");
$login_result=mysql_fetch_assoc($sql_login);
$login_rows=mysql_num_rows($sql_login);

$db_username=$login_result['username'];
$db_password=$login_result['password'];
$db_company=$login_result['company'];
$db_role=$login_result['role'];
$db_attempt=$login_result['attempt'];
$db_block=$login_result['block'];
$db_status=$login_result['status'];
$db_activation=$login_result['activation'];

//Query for Application
$app_sql_login=mysql_query("select * from application_form where username='$username' && app_status=0");
$app_sql_result=mysql_fetch_assoc($app_sql_login);
$app_sql_rows=mysql_num_rows($app_sql_login);

$app_db_username=$app_sql_result['username'];
$app_db_password=$app_sql_result['password'];


//Query for Student
$student_sql_login=mysql_query("select * from application_form where username='$username'");
$student_login_result=mysql_fetch_assoc($student_sql_login);
$student_login_rows=mysql_num_rows($student_sql_login);

$student_db_username=$student_login_result['username'];
$student_db_password=$student_login_result['password'];
$student_db_adm_status=$student_login_result['adm_status'];
$student_db_app_status=$student_login_result['app_status'];

if($username=="" || $password=="")
{
	$error="<font color='#FF0000'>Enter Login Details</font>";
}else

if($student_db_username == $username && $student_db_password != $password)
{
	$error="<font color='#FF0000'>Invalid Username or Password</font>";
}else

if($student_db_username==$username && $student_db_password==$password && $student_db_adm_status=='Admitted')
{

  echo  '<script language="javascript">window.alert("You have been admitted, your account will be setup after completing registration"); </script>'; 

/*	session_start();
	$_SESSION['student']= $student_db_username;
	$_SESSION['timestamp'] = time();
	header("location: student_pages/index.php");	//goto Student Page
*/}else

if($student_db_username==$username && $student_db_password==$password && $student_db_app_status=='0')
{
	session_start();
	$_SESSION['student']= $student_db_username;
	$_SESSION['timestamp'] = time();
	header("location: application_form.php");	//goto Student Page
}else

/* //FOR APPLICATION
if($student_db_username==$username && $student_db_password==$password && $student_db_adm_status=='Admitted')
{
	session_start();
	$_SESSION['student']= $student_db_username;
	$_SESSION['timestamp'] = time();
	header("location: student_pages/index.php");	//goto Student Page
}else
	
 */	

//Login For Administrators
if($db_username == $username && $db_password != $password)
{
	//updating attempt with +1 if password is invalid
	mysql_query("update administrators set attempt=(attempt+1) where username='$username'");
	if($db_attempt > 2 && $db_role != 'superadmin')
	{
		//updating block to 1 if password is entered wrongly 3 times
		mysql_query("update administrators set block=1 where username='$username'");
	}
	$error="<font color='#FF0000'>Invalid Username or Password</font>";
}else
if($db_username==$username && $db_password==$password && $db_block==1 && $db_activation==1)
{
	$error="<font color='#FF0000'>Account Blocked</font>";
}else
if($db_username==$username && $db_password==$password && $db_block==0 && $db_activation==0 && $db_role=='superadmin')
{
	session_start();
	$_SESSION['superadmin']= $db_username;
	$_SESSION['timestamp'] = time();
	header("location: s_pages/profile_reg.php");	//goto profile registration page (superadmin)
}else
if($db_username==$username && $db_password==$password && $db_block==0 && $db_activation==0 && $db_role=='admin')
{
	session_start();
	$_SESSION['admin']= $db_username;
	$_SESSION['timestamp'] = time();
	header("location: a_pages/profile_reg.php");	//goto profile registration page (admin)
}else
if($db_username==$username && $db_password==$password && $db_block==0 && $db_activation==1 && $db_attempt>2 && $db_role=='superadmin')
{
	session_start();
	$_SESSION['superadmin']= $db_username;
	$_SESSION['timestamp'] = time();
	header("location: s_pages/confirm_id.php"); //ask security question (superadmin)
}else
if($db_username==$username && $db_password==$password && $db_block==0 && $db_activation==1 && $db_attempt>2 && $db_role=='admin')
{
	session_start();
	$_SESSION['admin']= $db_username;
	$_SESSION['timestamp'] = time();
	header("location: a_pages/confirm_id.php"); //ask security question (admin)
}else
if($db_username==$username && $db_password==$password && $db_block==0 && $db_activation==1 && $db_role=='superadmin')
{
	session_start();
	$_SESSION['superadmin']= $db_username;
	$_SESSION['timestamp'] = time();
	mysql_query("update administrators set status=1 where username='$db_username'");
	header("location: s_pages/index.php"); //goto superadmin homepage
}else
if($db_username==$username && $db_password==$password && $db_block==0 && $db_activation==1 && $db_role=='admin')
{
	session_start();
	$_SESSION['admin']= $db_username;
	$_SESSION['timestamp'] = time();
	mysql_query("update administrators set status=1 where username='$db_username'");
	header("location: a_pages/index.php"); //goto admin homepage
}else
{
	$error="<font color='#FF0000'>Login Failed. Try Again Later</font>";
}
}
?>
