<?php
/* $db_state=mysql_query("select * from states ");
while($db_result=mysql_fetch_array($db_state)){
echo "<option value=$db_result[id]>$db_result[state]</option>";
} */


$q=mysql_query("select * from states ");
while($n=mysql_fetch_array($q)){
echo "<option value=$n[state_id]>$n[state]</option>";
}


?>
