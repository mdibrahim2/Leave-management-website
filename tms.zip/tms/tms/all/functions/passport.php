<?php
 define ("MAX_SIZE","1000"); 
 function getExtension($str) {
         $i = strrpos($str,".");
         if (!$i) { return ""; }
         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
 }
 $errors=0;
 if(isset($_POST['Upload'])) 
 {
 	$image=$_FILES['image']['name'];
 	if ($image) 
 	{
 		$filename = stripslashes($_FILES['image']['name']);
  		$extension = getExtension($filename);
 		$extension = strtolower($extension);
 if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) 
 		{
 			echo '<h1>Unknown extension!</h1>';
 			$errors=1;
 		}
 		else
 		{
 $size=filesize($_FILES['image']['tmp_name']);
if ($size > MAX_SIZE*1024)
{
	echo '<h3>Your picture must not exceed 100KB</h3>';
	$errors=1;
}
$image_name=time().'.'.$extension;
$newname="student_photos/".$image_name;
$copied = copy($_FILES['image']['tmp_name'], $newname);
if (!$copied) 
{
	echo '<h1>Copy unsuccessfull!</h1>';
	$errors=1;
}}}}
 if(isset($_POST['Submit']) && !$errors) 
 {
 }
 
 ?>