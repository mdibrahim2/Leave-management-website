<?php
function convert_state($id) {
	$sql_state=mysql_query("select * from states where state_id='$id'");
	$state_result=mysql_fetch_assoc($sql_state);
	return $state_result['state'];
}   
function convert_faculty($id) {
	$sql_state=mysql_query("select * from faculties where id='$id'");
	$state_result=mysql_fetch_assoc($sql_state);
	return $state_result['faculty'];
}  
function convert_school($id) {
	$sql_category=mysql_query("select * from schools where s_id='$id'");
	$category_result=mysql_fetch_assoc($sql_category);
	return $category_result['school'];
}


function convert_department($id) {
	$sql_dept=mysql_query("select * from departments where id='$id'");
	$dept_result=mysql_fetch_assoc($sql_dept);
	return $dept_result['department'];
}

function convert_programme($id) {
	$sql_pro=mysql_query("select * from programmes where id='$id'");
	$pro_result=mysql_fetch_assoc($sql_pro);
	return $pro_result['programme'];
}

function get_department($id) {
	$sql_pro=mysql_query("select * from programmes where id='$id'");
	$pro_result=mysql_fetch_assoc($sql_pro);
	$department=$pro_result['department'];
	return convert_department($department);
}

function get_faculty($id) {
	$sql_pro=mysql_query("select * from programmes where id='$id'");
	$pro_result=mysql_fetch_assoc($sql_pro);
	$department=$pro_result['department'];


	$sql_pro2=mysql_query("select * from departments where id='$department'");
	$pro_result2=mysql_fetch_assoc($sql_pro2);
	$faculty_id=$pro_result2['faculty_id'];
	return convert_faculty($faculty_id);
}



function get_reg_no($state,$programme,$app_no){
$short_state=substr($state,0,3);
$short_programme=substr($programme,0,3);
$short_app_no=substr($app_no,5);
return strtoupper($RegNo="15/".$short_state."/".$short_app_no."/".$short_programme."-J");


}

	function text_applicant($number,$name,$programme){
	/* Variables with the values to be sent. */
	$owneremail="muhammaddibrahim2@gmail.com";
	$subacct="MDI2018";
	$subacctpwd="mdi123456";
	$sendto=$number; /* destination number */
	$sender="SICHST MKRF."; /* sender id */
	$message="Dear $name, Congratulations!, your application for\\\\\\\. was accepted. \nYou are requested to come for screening on  6-4-2015 \n";
	
	 /* message to be sent */
	$msgtype="0"; //E.g if message is not flash message, 1 is for flash message.
	/* create the required URL */
	$url = "http://www.smslive247.com/http/index.aspx?"
	. "cmd=sendquickmsg"
	. "&owneremail=" . UrlEncode($owneremail)
	. "&subacct=" . UrlEncode($subacct)
	. "&subacctpwd=" . UrlEncode($subacctpwd)
	. "&message=" . UrlEncode($message)
	. "&sender=" . UrlEncode($sender)
	. "&sendto=" . UrlEncode($sendto)
	. "&msgtype=" . UrlEncode($msgtype);
	
	/* call the URL */
	if ($f = @fopen($url, "r"))
	{
	$answer = fgets($f, 255);
	if (substr($answer, 0, 1) == "+")
	{
	echo "SMS to $dnr was successful.";
	}
	else
	{
	//echo "an error has occurred: [$answer].";
	$sent="SMS was successfully Sent";
	
	}
	}
	else
	{
	echo "Error: URL could not be opened.";
	}
	
	}
	

//Function to convert date format
function convert_date($date){

$newDate = date("d-m-Y", strtotime($date));
return $newDate;
}
	
	
?>