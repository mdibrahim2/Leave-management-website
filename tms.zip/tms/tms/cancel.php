<?php
	
    $host = "localhost";
    $databse = "tms";
    $db_user = "root";
    $db_pass = "";
    $connect = mysqli_connect($host, $db_user, $db_pass, $databse) or 
    die("Cannot connect"); 
    
    mysqli_select_db( $connect, $databse);
    

include_once('../include/setting.php');
	$s_id=$_GET['bkid'];
	mysqli_query($connect,"delete from tblbooking where BookingId='$s_id'") or die(mysql_error());
	header('location:tour-history.php');
?>