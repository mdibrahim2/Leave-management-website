<div class="copyrights" style="background-color:#033">
	 <p>© 2019 TMS. All Rights Reserved | Design By Muhammad Yaya Ibrahim  <a href="#">TMS</a> </p>
</div>	
