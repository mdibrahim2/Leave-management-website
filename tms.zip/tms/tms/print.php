<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0)
	{	
header('location:index.php');
}
else{
if(isset($_REQUEST['bkid']))
	{
		$bid=intval($_GET['bkid']);
$email=$_SESSION['login'];

	$sql ="SELECT FromDate FROM tblbooking WHERE UserEmail=:email and BookingId=:bid";
$query= $dbh -> prepare($sql);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> bindParam(':bid', $bid, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
foreach($results as $result)
{
	 $fdate=$result->FromDate;

	$a=explode("/",$fdate);
	$val=array_reverse($a);
	 $mydate =implode("/",$val);
	$cdate=date('Y/m/d');
	$date1=date_create("$cdate");
	$date2=date_create("$fdate");
 $diff=date_diff($date1,$date2);
echo $df=$diff->format("%a");
if($df>1)
{
$status=2;
$cancelby='u';
$sql = "UPDATE tblbooking SET status=:status,CancelledBy=:cancelby WHERE UserEmail=:email and BookingId=:bid";
$query = $dbh->prepare($sql);
$query -> bindParam(':status',$status, PDO::PARAM_STR);
$query -> bindParam(':cancelby',$cancelby , PDO::PARAM_STR);
$query-> bindParam(':email',$email, PDO::PARAM_STR);
$query-> bindParam(':bid',$bid, PDO::PARAM_STR);
$query -> execute();

$msg="Booking Cancelled successfully";
}
else
{
$error="You can't cancel booking before 24 hours";
}
}
}
}

?>
<!DOCTYPE HTML>
<html>
<head>
<title>TMS | Tourism Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tourism Management System In PHP" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<!-- Bootstrap Core CSS -->
<link href="all/css/bootstrap.min.css" rel="stylesheet">
	
	<!-- Default Layout -->
	<link href="all/css/style.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="print.css">
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<style type="text/css">
<!--
.style4 {font-size: 12px}
.style5 {
	font-size: 24px;
	font-weight: bold;
	font-family: "Times New Roman", Times, serif;
}
.style7 {font-size: 12px; color: #009900; }
.style11 {color: #3300CC; font-weight: bold; }
.style12 {color: #3300CC}
.style13 {
	font-size: 14px;
	font-weight: bold;
}
.style3 {	font-size: 12px;
	font-weight: bold;
}
</style>
<?php	$bid=intval($_GET['bkid']);
$email=$_SESSION['login'];
$fname=$_SESSION['fname'];
        $sql = "SELECT tblbooking.FromDate,tblbooking.ToDate, DATEDIFF(tblbooking.ToDate,tblbooking.FromDate) as mdi, tblbooking.BookingId as bookid,tblbooking.PackageId as pkgid,tbltourpackages.PackageName as packagename, tbltourpackages.PackagePrice as price, tblbooking.FromDate as fromdate,tblbooking.ToDate as todate,tblbooking.Comment as comment,tblbooking.status as status,tblbooking.RegDate as regdate,tblbooking.CancelledBy as cancelby,tblbooking.UpdationDate as upddate from tblbooking join tbltourpackages on tbltourpackages.PackageId=tblbooking.PackageId where  UserEmail=:email and BookingId=:bid";
        $query = $dbh->prepare($sql);
        $query-> bindParam(':email', $email, PDO::PARAM_STR);
        $query-> bindParam(':bid', $bid, PDO::PARAM_STR);
        $query->execute();
        $result=$query->fetchAll(PDO::FETCH_OBJ);
        $cnt=1;
    
        ?>
<br><br><center>

<div id="work_space" align="center" style="height:400px; border:px;">
<br><br><br><br>
<table width="800" align="center">
  <tr>
    <td height="28" colspan="6" class="style5"><div align="center">M.YAYA TOUR CENTER NIGERIAN LIMITED</div></td>
  </tr>
  <tr >
    <td height="42" colspan="6"><div align="center"><span class="style7">Head Office: dundubawa layin yan tumaki kano state Nigeria</span></div></td>
  </tr>
  <tr >
    <td colspan="2"><span class="style13">Booking invoice</span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2"><div align="right"><span class="style4"><?php echo date('jS F Y h:i:sa', time()); ?></span></div></td>
  </tr>
  <tr >
    <td height="24">Name:</td>
    <td colspan="2"><?php 

echo $md=$_SESSION['fname'];;?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td >&nbsp;</td>
  </tr>
  <tr >
    <td height="40">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td ><div align="right"></div></td>
  </tr>
  <tr class="current_page_item" >
    <td width="62">&nbsp;</td>
    <td width="309"><span class="style12"><strong>Package Name </strong></span></td>
    <td width="143"><span class="style4 style12"><strong>From</strong></span></td>
    <td width="86"><span class="style12 style4"><strong>ToDate</strong></span></td>
    <td width="94"><span class="style11">Days</span></td>
    <td width="94"><span class="style11">Price Per Day</span></td>
    <td width="84"><div align="right"><span class="style12"><strong>Total</strong></span></div></td>
  </tr>
<?php 

$uemail=$_SESSION['login'];;
$sql = "SELECT tblbooking.FromDate,tblbooking.ToDate, DATEDIFF(tblbooking.ToDate,tblbooking.FromDate) as mdi, tblbooking.UserEmail as k, tblbooking.BookingId as bookid,tblbooking.PackageId as pkgid,tbltourpackages.PackageName as packagename, tbltourpackages.PackagePrice as price, tblbooking.FromDate as fromdate,tblbooking.ToDate as todate,tblbooking.Comment as comment,tblbooking.status as status,tblbooking.RegDate as regdate,tblbooking.CancelledBy as cancelby,tblbooking.UpdationDate as upddate from tblbooking join tbltourpackages on tbltourpackages.PackageId=tblbooking.PackageId where UserEmail=:uemail";
$query = $dbh->prepare($sql);
$query -> bindParam(':uemail', $uemail, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{	?>

  <tr class="current_page_item" >
    <td width="62">&nbsp;</td>
    <td width="159"><span class="style12"><strong><?php echo htmlentities($result->packagename);?> </strong></span></td>
    <td width="143"><span class="style4 style12"><strong><?php echo htmlentities($result->FromDate); ?> </strong></span></td>
    <td width="86"><span class="style12 style4"><strong><?php echo htmlentities($result->ToDate);?></strong></span></td>
    <td width="94"><span class="style11"><?php echo htmlentities($mdi=$result->mdi);?></span></td>
    
    <td width="94"><span class="style11"><?php echo htmlentities($result->price);?></span></td>
     </tr>
 
    <tr>
      <td height="40">&nbsp;</td>
      <td><span class="style3">
      <a href="index.php" >Finish </a>
      </span></td>
      <td><a href="javascript:window.print()">PRINT INVOICE</a></td>
      <td></td>
      <td><div align="right"><strong>Grand Total:</strong></div></td>
      <td> <?php $day=$result->mdi; $p=$result->price;?>   <div align="right"><strong>
        <?php // do the calculation job here.
echo $p*$day;
?>
      </strong></div></td>
    </tr>
<?php $cnt=$cnt+1; }} ?>
	</table>
		
			</p>
			</form>
<?php }?>
</div>
<center>
</body>
</html>