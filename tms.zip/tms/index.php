<?php 
    header("Location: tms/index.php");?>